# ffx-hooks v0.1.0-beta.1 — Install

## BETA — read before using

This is a beta release of a project that just left alpha. Expect bugs and mod
incompatibilities. **Use a disposable save.** All hooks are OFF by default.

## Requirements

- FINAL FANTASY X/X-2 HD Remaster (Steam, PC)
- .NET 8 runtime (for SinScaleInject)
- The FFX module loader (`dinput8.dll` proxy in the game directory)

## Install

1. Back up your game's `modules\` folder.
2. Copy `ffx-hooks.dll` and `ffx-probe.dll` into `<game>\modules\`.
3. Copy `ffx-hooks.ini` into `<game>\` (root, next to `FFX.exe`).
4. Copy the `SinScaleInject\` folder into `<game>\modules\tools\SinScaleInject\`.
5. Arm a feature (game closed):

```
New-Item -ItemType File "<game>\modules\config\f7_inlive.flag"
```

6. Launch FFX, press F7 in-game.

## What works

- **F7 In-Live menu**: difficulty levers (RAM-only), Force Last Battle, music
  control, Monster AI Swap.

## What's disabled / planned

- **F8 Dashboard**: implemented, disabled (`[dashboard] enabled=0`). Next release.
- **ffx-probe**: included but off by default (rename to activate).
- **Playable Seymour**: OFF — pending RE validation.

## Known bugs

See the release notes below for the full known-bugs list.

## Uninstall

Delete the flag files, delete the DLLs, restart FFX. Everything is RAM-only
and reversible.
